int  common(int opcode_operand, int reg_operand, int other_operand, int displ, int direction);
void fix_offset();
void add_to_code_stack(char code);
void print_character_in_binary(char character);
void print_integer_in_binary(int integer);
void print_code_stack();
void print_code_stack_in_hex();
