
/* tokens */

#define DO 257
#define END 258
#define ENDIF 259
#define EQ 260
#define GT 261
#define GTE 262
#define IDENTIFIER 263
#define IF 264
#define INPUT 265
#define INT 266
#define LT 267
#define LTE 268
#define MAIN 269
#define NE 270
#define NUMBER 271
#define OUTPUT 272
#define STEP 273
#define STRING 274
#define TO 275
#define WEND 276
#define WHILE 277
